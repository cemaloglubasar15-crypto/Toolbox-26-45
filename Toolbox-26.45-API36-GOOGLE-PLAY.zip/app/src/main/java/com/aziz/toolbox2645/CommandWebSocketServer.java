package com.aziz.toolbox2645;

import android.util.Base64;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;

public final class CommandWebSocketServer {

    public interface Listener {
        void onConnectionChanged(boolean connected);
    }

    private static final CommandWebSocketServer INSTANCE = new CommandWebSocketServer();
    public static CommandWebSocketServer get() { return INSTANCE; }

    private final CopyOnWriteArrayList<Listener> listeners = new CopyOnWriteArrayList<>();
    private volatile ServerSocket server;
    private volatile Socket client;
    private volatile OutputStream clientOut;
    private volatile boolean running;

    private CommandWebSocketServer() {}

    public void addListener(Listener l) { if (l != null) listeners.addIfAbsent(l); }
    public void removeListener(Listener l) { listeners.remove(l); }

    public boolean isConnected() {
        Socket c = client;
        return c != null && c.isConnected() && !c.isClosed();
    }

    public synchronized void start(int port) {
        if (running) return;
        running = true;
        Thread t = new Thread(() -> acceptLoop(port), "Toolbox-WS");
        t.setDaemon(true);
        t.start();
    }

    public synchronized void stop() {
        running = false;
        closeClient();
        try { if (server != null) server.close(); } catch (Exception ignored) {}
        server = null;
    }

    private void acceptLoop(int port) {
        try {
            server = new ServerSocket(port, 1, InetAddress.getByName("127.0.0.1"));
            server.setReuseAddress(true);
            while (running) {
                Socket s = server.accept();
                try {
                    handshake(s);
                    closeClient();
                    client = s;
                    clientOut = s.getOutputStream();
                    fire(true);

                    Thread reader = new Thread(() -> readFrames(s), "Toolbox-WS-Reader");
                    reader.setDaemon(true);
                    reader.start();
                } catch (Exception e) {
                    try { s.close(); } catch (Exception ignored) {}
                }
            }
        } catch (Exception ignored) {
        } finally {
            running = false;
            closeClient();
        }
    }

    private void handshake(Socket s) throws Exception {
        InputStream in = s.getInputStream();
        ByteArrayOutputStream req = new ByteArrayOutputStream();
        int a=0,b=0,c=0,d=0;
        while (req.size() < 32768) {
            int x = in.read();
            if (x < 0) throw new Exception("EOF");
            req.write(x);
            a=b; b=c; c=d; d=x;
            if (a==13 && b==10 && c==13 && d==10) break;
        }
        String headers = req.toString(StandardCharsets.UTF_8.name());
        String key = null;
        for (String line : headers.split("\\r\\n")) {
            int idx = line.indexOf(':');
            if (idx > 0 && line.substring(0, idx).trim().equalsIgnoreCase("Sec-WebSocket-Key")) {
                key = line.substring(idx + 1).trim();
                break;
            }
        }
        if (key == null) throw new Exception("WebSocket key missing");

        String magic = key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";
        byte[] sha = MessageDigest.getInstance("SHA-1").digest(magic.getBytes(StandardCharsets.UTF_8));
        String accept = Base64.encodeToString(sha, Base64.NO_WRAP);

        String response =
                "HTTP/1.1 101 Switching Protocols\\r\\n" +
                "Upgrade: websocket\\r\\n" +
                "Connection: Upgrade\\r\\n" +
                "Sec-WebSocket-Accept: " + accept + "\\r\\n\\r\\n";
        OutputStream out = s.getOutputStream();
        out.write(response.getBytes(StandardCharsets.UTF_8));
        out.flush();
    }

    private void readFrames(Socket s) {
        try {
            InputStream in = s.getInputStream();
            while (running && s == client && !s.isClosed()) {
                int b0 = in.read();
                if (b0 < 0) break;
                int b1 = in.read();
                if (b1 < 0) break;

                int opcode = b0 & 0x0F;
                boolean masked = (b1 & 0x80) != 0;
                long len = b1 & 0x7F;

                if (len == 126) {
                    len = ((in.read() & 0xFF) << 8) | (in.read() & 0xFF);
                } else if (len == 127) {
                    len = 0;
                    for (int i=0;i<8;i++) len = (len << 8) | (in.read() & 0xFF);
                }
                if (len > 4_000_000) throw new Exception("Frame too large");

                byte[] mask = null;
                if (masked) {
                    mask = new byte[4];
                    readFully(in, mask);
                }

                byte[] payload = new byte[(int) len];
                readFully(in, payload);
                if (masked) {
                    for (int i=0;i<payload.length;i++) payload[i] ^= mask[i & 3];
                }

                if (opcode == 0x8) break;
                if (opcode == 0x9) sendFrame((byte)0xA, payload);
            }
        } catch (Exception ignored) {
        } finally {
            if (s == client) closeClient();
        }
    }

    private static void readFully(InputStream in, byte[] buf) throws Exception {
        int off = 0;
        while (off < buf.length) {
            int n = in.read(buf, off, buf.length - off);
            if (n < 0) throw new Exception("EOF");
            off += n;
        }
    }

    private synchronized void closeClient() {
        boolean was = isConnected();
        try { if (client != null) client.close(); } catch (Exception ignored) {}
        client = null;
        clientOut = null;
        if (was) fire(false);
    }

    private void fire(boolean connected) {
        for (Listener l : listeners) {
            try { l.onConnectionChanged(connected); } catch (Exception ignored) {}
        }
    }

    private synchronized boolean sendFrame(byte opcode, byte[] payload) {
        OutputStream out = clientOut;
        if (out == null || !isConnected()) return false;
        try {
            out.write(0x80 | (opcode & 0x0F));
            int len = payload.length;
            if (len <= 125) {
                out.write(len);
            } else if (len <= 65535) {
                out.write(126);
                out.write((len >>> 8) & 0xFF);
                out.write(len & 0xFF);
            } else {
                out.write(127);
                for (int i=7;i>=0;i--) out.write((len >>> (8*i)) & 0xFF);
            }
            out.write(payload);
            out.flush();
            return true;
        } catch (Exception e) {
            closeClient();
            return false;
        }
    }

    public boolean sendCommand(String command) {
        try {
            String cmd = command == null ? "" : command.trim();
            if (cmd.isEmpty()) return false;
            if (!cmd.startsWith("/")) cmd = "/" + cmd;

            JSONObject root = new JSONObject();
            JSONObject header = new JSONObject();
            header.put("version", 1);
            header.put("requestId", UUID.randomUUID().toString());
            header.put("messageType", "commandRequest");
            header.put("messagePurpose", "commandRequest");

            JSONObject origin = new JSONObject();
            origin.put("type", "player");

            JSONObject body = new JSONObject();
            body.put("version", 1);
            body.put("commandLine", cmd);
            body.put("origin", origin);

            root.put("header", header);
            root.put("body", body);

            return sendFrame((byte)0x1, root.toString().getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) {
            return false;
        }
    }
}
