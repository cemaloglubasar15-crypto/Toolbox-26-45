package com.aziz.toolbox2645;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class OverlayService extends Service implements CommandWebSocketServer.Listener {

    private static final String CHANNEL = "toolbox2645";
    private static final int MAX_FLOATING_SHORTCUTS = 8;

    private WindowManager wm;
    private ImageView bubble;
    private LinearLayout panel;
    private TextView statusText;
    private WindowManager.LayoutParams bubbleLp;
    private WindowManager.LayoutParams panelLp;

    private final List<Shortcut> shortcuts = new ArrayList<>();
    private final List<Button> floatingButtons = new ArrayList<>();

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();
        Notification n = new Notification.Builder(this, CHANNEL)
                .setContentTitle("Toolbox 26.45")
                .setContentText("Minecraft HUD hazır")
                .setSmallIcon(android.R.drawable.ic_menu_manage)
                .setOngoing(true)
                .build();
        startForeground(2645, n);

        CommandWebSocketServer.get().addListener(this);
        CommandWebSocketServer.get().start(19132);

        loadShortcuts();
        if (Settings.canDrawOverlays(this)) createOverlay();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        CommandWebSocketServer.get().start(19132);
        if (bubble == null && Settings.canDrawOverlays(this)) createOverlay();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        CommandWebSocketServer.get().removeListener(this);
        removeFloatingShortcuts();
        if (wm != null) {
            try { if (bubble != null) wm.removeView(bubble); } catch (Exception ignored) {}
            try { if (panel != null) wm.removeView(panel); } catch (Exception ignored) {}
        }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(
                    CHANNEL, "Toolbox HUD", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Toolbox yüzen düğmesi ve yerel Minecraft bağlantısı");
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }

    private int overlayType() {
        return Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
    }

    private GradientDrawable bg(int color, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp((int) radius));
        return g;
    }

    private GradientDrawable circleBg(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        return g;
    }

    private void createOverlay() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);

        bubble = new ImageView(this);
        bubble.setImageResource(R.drawable.toolbox_icon);
        bubble.setScaleType(ImageView.ScaleType.CENTER_CROP);
        bubble.setBackground(bg(Color.argb(235, 125, 225, 100), 18));
        bubble.setPadding(dp(3), dp(3), dp(3), dp(3));

        bubbleLp = new WindowManager.LayoutParams(
                dp(62), dp(62), overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        bubbleLp.gravity = Gravity.TOP | Gravity.START;
        bubbleLp.x = getSharedPreferences("toolbox", MODE_PRIVATE)
                .getInt("main_bubble_x", dp(18));
        bubbleLp.y = getSharedPreferences("toolbox", MODE_PRIVATE)
                .getInt("main_bubble_y", dp(180));
        wm.addView(bubble, bubbleLp);
        bubble.setOnTouchListener(new MainBubbleTouch());

        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(12), dp(12), dp(12), dp(12));
        panel.setBackground(bg(Color.argb(242, 22, 27, 22), 18));
        panel.setVisibility(View.GONE);

        panelLp = new WindowManager.LayoutParams(
                dp(292), WindowManager.LayoutParams.WRAP_CONTENT, overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL |
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        panelLp.gravity = Gravity.TOP | Gravity.START;
        panelLp.x = dp(78);
        panelLp.y = dp(100);
        wm.addView(panel, panelLp);

        rebuildPanel();
        refreshFloatingShortcuts();
    }

    private TextView label(String text, int size, int color) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setPadding(dp(6), dp(5), dp(6), dp(5));
        return t;
    }

    private Button menuButton(String title) {
        Button b = new Button(this);
        b.setText(title);
        b.setAllCaps(false);
        b.setTextSize(14);
        return b;
    }

    private void rebuildPanel() {
        if (panel == null) return;
        panel.removeAllViews();

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);

        ImageView icon = new ImageView(this);
        icon.setImageResource(R.drawable.toolbox_icon);
        header.addView(icon, new LinearLayout.LayoutParams(dp(40), dp(40)));

        TextView title = label("  TOOLBOX 26.45", 18, Color.WHITE);
        title.setTypeface(null, 1);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1));

        Button close = menuButton("×");
        close.setOnClickListener(v -> panel.setVisibility(View.GONE));
        header.addView(close, new LinearLayout.LayoutParams(dp(46), dp(42)));
        panel.addView(header);

        statusText = label("", 12, Color.LTGRAY);
        panel.addView(statusText);
        updateStatus();

        TextView sec = label("KOMUT DAİRELERİ", 12, Color.rgb(120, 230, 120));
        sec.setTypeface(null, 1);
        panel.addView(sec);

        TextView hintCircles = label(
                "Renkli daireler ekranda bağımsız hareket eder. Sürükle = taşı • Dokun = çalıştır • Uzun bas = düzenle",
                11, Color.LTGRAY);
        panel.addView(hintCircles);

        LinearLayout shortcutControls = new LinearLayout(this);
        shortcutControls.setOrientation(LinearLayout.HORIZONTAL);
        Button add = menuButton("+ Daire Ekle");
        add.setOnClickListener(v -> addShortcut());
        shortcutControls.addView(add, new LinearLayout.LayoutParams(0, -2, 1));
        Button arrange = menuButton("Daireleri Göster");
        arrange.setOnClickListener(v -> refreshFloatingShortcuts());
        shortcutControls.addView(arrange, new LinearLayout.LayoutParams(0, -2, 1));
        panel.addView(shortcutControls);

        LinearLayout row1 = new LinearLayout(this);
        Button give = menuButton("Give Item");
        give.setOnClickListener(v -> showGive());
        row1.addView(give, new LinearLayout.LayoutParams(0, -2, 1));
        Button effect = menuButton("Effects");
        effect.setOnClickListener(v -> showEffect());
        row1.addView(effect, new LinearLayout.LayoutParams(0, -2, 1));
        panel.addView(row1);

        LinearLayout row2 = new LinearLayout(this);
        Button enchant = menuButton("Enchant");
        enchant.setOnClickListener(v -> showEnchant());
        row2.addView(enchant, new LinearLayout.LayoutParams(0, -2, 1));
        Button free = menuButton("Free Camera");
        free.setOnClickListener(v -> {
            run("camera @s set minecraft:free");
            run("controlscheme @s set camera_relative");
        });
        row2.addView(free, new LinearLayout.LayoutParams(0, -2, 1));
        panel.addView(row2);

        LinearLayout row3 = new LinearLayout(this);
        Button heal = menuButton("Heal");
        heal.setOnClickListener(v -> run("effect @s instant_health 1 10 true"));
        row3.addView(heal, new LinearLayout.LayoutParams(0, -2, 1));
        Button feed = menuButton("Feed");
        feed.setOnClickListener(v -> run("effect @s saturation 1 10 true"));
        row3.addView(feed, new LinearLayout.LayoutParams(0, -2, 1));
        Button clear = menuButton("Clear");
        clear.setOnClickListener(v -> run("clear @s"));
        row3.addView(clear, new LinearLayout.LayoutParams(0, -2, 1));
        panel.addView(row3);

        LinearLayout row4 = new LinearLayout(this);
        Button resetCam = menuButton("Camera Reset");
        resetCam.setOnClickListener(v -> {
            run("camera @s clear");
            run("controlscheme @s clear");
        });
        row4.addView(resetCam, new LinearLayout.LayoutParams(0, -2, 1));

        Button mc = menuButton("Minecraft");
        mc.setOnClickListener(v -> {
            Intent i = getPackageManager().getLaunchIntentForPackage("com.mojang.minecraftpe");
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            }
        });
        row4.addView(mc, new LinearLayout.LayoutParams(0, -2, 1));
        panel.addView(row4);

        TextView hint = label(
                "Bağlantı: önce HUD'u başlat, sonra hileleri açık dünyada /connect 127.0.0.1:19132 yaz.",
                11, Color.GRAY);
        panel.addView(hint);
    }

    private void togglePanel() {
        if (panel == null) return;
        if (panel.getVisibility() == View.VISIBLE) panel.setVisibility(View.GONE);
        else {
            rebuildPanel();
            panel.setVisibility(View.VISIBLE);
        }
    }

    private void run(String command) {
        boolean ok = CommandWebSocketServer.get().sendCommand(command);
        Toast.makeText(this,
                ok ? "Çalıştırıldı: /" + command.replaceFirst("^/+", "")
                        : "Minecraft bağlı değil. Oyunda: /connect 127.0.0.1:19132",
                Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onConnectionChanged(boolean connected) {
        if (statusText != null) statusText.post(this::updateStatus);
    }

    private void updateStatus() {
        if (statusText == null) return;
        boolean c = CommandWebSocketServer.get().isConnected();
        statusText.setText(c ? "● Minecraft BAĞLI" : "○ Minecraft bağlantısı bekleniyor");
        statusText.setTextColor(c ? Color.rgb(90, 240, 105) : Color.LTGRAY);
    }

    private void showGive() {
        LinearLayout box = dialogBox();
        EditText item = edit("diamond");
        EditText count = edit("64");
        box.addView(label("Eşya ID", 13, Color.DKGRAY));
        box.addView(item);
        box.addView(label("Miktar", 13, Color.DKGRAY));
        box.addView(count);

        AlertDialog ad = new AlertDialog.Builder(this)
                .setTitle("Give Item")
                .setView(box)
                .setPositiveButton("Ver", (d, w) -> {
                    String id = item.getText().toString().trim();
                    String n = count.getText().toString().trim();
                    if (!id.matches("[A-Za-z0-9_:\\-.]+")) {
                        Toast.makeText(this, "Geçersiz eşya ID", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    run("give @s " + id + " " + (n.isEmpty() ? "1" : n));
                })
                .setNegativeButton("İptal", null)
                .create();
        showOverlayDialog(ad);
    }

    private void showEffect() {
        LinearLayout box = dialogBox();
        Spinner effects = new Spinner(this);
        String[] names = {"speed", "strength", "night_vision", "invisibility", "jump_boost",
                "regeneration", "resistance", "haste", "water_breathing"};
        effects.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, names));
        EditText duration = edit("infinite");
        EditText level = edit("1");
        box.addView(effects);
        box.addView(label("Süre (saniye veya infinite)", 13, Color.DKGRAY));
        box.addView(duration);
        box.addView(label("Seviye", 13, Color.DKGRAY));
        box.addView(level);

        AlertDialog ad = new AlertDialog.Builder(this)
                .setTitle("Effects")
                .setView(box)
                .setPositiveButton("Uygula", (d, w) -> run("effect @s " +
                        effects.getSelectedItem().toString() + " " +
                        duration.getText().toString().trim() + " " +
                        level.getText().toString().trim() + " true"))
                .setNegativeButton("İptal", null)
                .create();
        showOverlayDialog(ad);
    }

    private void showEnchant() {
        LinearLayout box = dialogBox();
        Spinner enchant = new Spinner(this);
        String[] names = {"sharpness", "efficiency", "unbreaking", "fortune", "protection",
                "power", "infinity", "mending", "looting", "silk_touch"};
        enchant.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, names));
        EditText level = edit("1");
        box.addView(enchant);
        box.addView(label("Seviye", 13, Color.DKGRAY));
        box.addView(level);

        AlertDialog ad = new AlertDialog.Builder(this)
                .setTitle("Enchant")
                .setView(box)
                .setPositiveButton("Uygula", (d, w) -> run("enchant @s " +
                        enchant.getSelectedItem().toString() + " " +
                        level.getText().toString().trim()))
                .setNegativeButton("İptal", null)
                .create();
        showOverlayDialog(ad);
    }

    private LinearLayout dialogBox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(8), dp(18), dp(4));
        return l;
    }

    private EditText edit(String value) {
        EditText e = new EditText(this);
        e.setText(value);
        e.setSingleLine(true);
        return e;
    }

    private void showOverlayDialog(AlertDialog ad) {
        try {
            Window w = ad.getWindow();
            if (w != null) w.setType(overlayType());
            ad.show();
        } catch (Exception e) {
            Toast.makeText(this, "Pencere açılamadı: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void addShortcut() {
        showShortcutDialog(null);
    }

    private void editShortcut(Shortcut s) {
        showShortcutDialog(s);
    }

    private void showShortcutDialog(Shortcut existing) {
        LinearLayout box = dialogBox();
        EditText name = edit(existing == null ? "Komut" : existing.name);
        EditText cmd = edit(existing == null ? "give @s diamond 64" : existing.command);
        Spinner color = new Spinner(this);
        String[] colors = {"Mavi", "Yeşil", "Kırmızı", "Turuncu", "Mor", "Sarı", "Siyah"};
        color.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, colors));

        box.addView(label("Daire adı", 13, Color.DKGRAY));
        box.addView(name);
        box.addView(label("Komut", 13, Color.DKGRAY));
        box.addView(cmd);
        box.addView(label("Renk", 13, Color.DKGRAY));
        box.addView(color);

        AlertDialog.Builder b = new AlertDialog.Builder(this)
                .setTitle(existing == null ? "Komut Dairesi Ekle" : "Komut Dairesini Düzenle")
                .setView(box)
                .setPositiveButton("Kaydet", (d, w) -> {
                    int c = colorValue(color.getSelectedItemPosition());
                    String title = name.getText().toString().trim();
                    if (title.isEmpty()) title = "Komut";
                    String command = cmd.getText().toString().trim();
                    if (existing == null) {
                        shortcuts.add(new Shortcut(UUID.randomUUID().toString(), title, command, c));
                    } else {
                        existing.name = title;
                        existing.command = command;
                        existing.color = c;
                    }
                    saveShortcuts();
                    rebuildPanel();
                    refreshFloatingShortcuts();
                })
                .setNegativeButton("İptal", null);

        if (existing != null) {
            b.setNeutralButton("Sil", (d, w) -> {
                shortcuts.remove(existing);
                saveShortcuts();
                rebuildPanel();
                refreshFloatingShortcuts();
            });
        }
        showOverlayDialog(b.create());
    }

    private int colorValue(int i) {
        switch (i) {
            case 1: return Color.rgb(52, 199, 89);
            case 2: return Color.rgb(255, 59, 48);
            case 3: return Color.rgb(255, 149, 0);
            case 4: return Color.rgb(175, 82, 222);
            case 5: return Color.rgb(255, 204, 0);
            case 6: return Color.rgb(28, 28, 30);
            default: return Color.rgb(39, 135, 255);
        }
    }

    private void loadShortcuts() {
        shortcuts.clear();
        boolean needsSave = false;
        try {
            String raw = getSharedPreferences("toolbox", MODE_PRIVATE)
                    .getString("shortcuts", "");
            if (!raw.isEmpty()) {
                JSONArray a = new JSONArray(raw);
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.getJSONObject(i);
                    String id = o.optString("id", "");
                    if (id.isEmpty()) {
                        id = UUID.randomUUID().toString();
                        needsSave = true;
                    }
                    shortcuts.add(new Shortcut(
                            id,
                            o.optString("name", "Komut"),
                            o.optString("command", "say Toolbox"),
                            o.optInt("color", Color.rgb(39, 135, 255))));
                }
            }
        } catch (Exception ignored) {}

        if (shortcuts.isEmpty()) {
            shortcuts.add(new Shortcut(UUID.randomUUID().toString(), "Elmas",
                    "give @s diamond 64", Color.rgb(39, 135, 255)));
            shortcuts.add(new Shortcut(UUID.randomUUID().toString(), "Speed",
                    "effect @s speed infinite 3 true", Color.rgb(255, 149, 0)));
            shortcuts.add(new Shortcut(UUID.randomUUID().toString(), "NV",
                    "effect @s night_vision infinite 1 true", Color.rgb(175, 82, 222)));
            needsSave = true;
        }
        if (needsSave) saveShortcuts();
    }

    private void saveShortcuts() {
        try {
            JSONArray a = new JSONArray();
            for (Shortcut s : shortcuts) {
                JSONObject o = new JSONObject();
                o.put("id", s.id);
                o.put("name", s.name);
                o.put("command", s.command);
                o.put("color", s.color);
                a.put(o);
            }
            getSharedPreferences("toolbox", MODE_PRIVATE).edit()
                    .putString("shortcuts", a.toString()).apply();
        } catch (Exception ignored) {}
    }

    private void removeFloatingShortcuts() {
        if (wm != null) {
            for (Button b : floatingButtons) {
                try { wm.removeView(b); } catch (Exception ignored) {}
            }
        }
        floatingButtons.clear();
    }

    private void refreshFloatingShortcuts() {
        if (wm == null) return;
        removeFloatingShortcuts();

        int count = Math.min(shortcuts.size(), MAX_FLOATING_SHORTCUTS);
        for (int i = 0; i < count; i++) {
            Shortcut s = shortcuts.get(i);
            Button b = new Button(this);
            String shown = s.name == null ? "CMD" : s.name;
            if (shown.length() > 6) shown = shown.substring(0, 6);
            b.setText(shown);
            b.setTextSize(9);
            b.setTextColor(Color.WHITE);
            b.setAllCaps(false);
            b.setMinWidth(0);
            b.setMinHeight(0);
            b.setPadding(0, 0, 0, 0);
            b.setBackground(circleBg(s.color));

            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    dp(56), dp(56), overlayType(),
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.START;

            int defaultX = dp(18 + (i % 4) * 66);
            int defaultY = dp(260 + (i / 4) * 66);
            lp.x = getSharedPreferences("toolbox", MODE_PRIVATE)
                    .getInt("shortcut_x_" + s.id, defaultX);
            lp.y = getSharedPreferences("toolbox", MODE_PRIVATE)
                    .getInt("shortcut_y_" + s.id, defaultY);

            b.setOnTouchListener(new ShortcutTouch(s, b, lp));
            wm.addView(b, lp);
            floatingButtons.add(b);
        }
    }

    private static class Shortcut {
        String id;
        String name;
        String command;
        int color;

        Shortcut(String id, String n, String c, int col) {
            this.id = id;
            name = n;
            command = c;
            color = col;
        }
    }

    private void clamp(WindowManager.LayoutParams lp, int sizeDp) {
        int maxX = Math.max(0, getResources().getDisplayMetrics().widthPixels - dp(sizeDp));
        int maxY = Math.max(0, getResources().getDisplayMetrics().heightPixels - dp(sizeDp));
        if (lp.x < 0) lp.x = 0;
        if (lp.y < 0) lp.y = 0;
        if (lp.x > maxX) lp.x = maxX;
        if (lp.y > maxY) lp.y = maxY;
    }

    private class MainBubbleTouch implements View.OnTouchListener {
        private int sx, sy;
        private float tx, ty;
        private long down;

        @Override
        public boolean onTouch(View v, MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    sx = bubbleLp.x;
                    sy = bubbleLp.y;
                    tx = e.getRawX();
                    ty = e.getRawY();
                    down = System.currentTimeMillis();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    bubbleLp.x = sx + (int) (e.getRawX() - tx);
                    bubbleLp.y = sy + (int) (e.getRawY() - ty);
                    clamp(bubbleLp, 62);
                    try { wm.updateViewLayout(bubble, bubbleLp); } catch (Exception ignored) {}
                    return true;
                case MotionEvent.ACTION_UP:
                    float dx = Math.abs(e.getRawX() - tx);
                    float dy = Math.abs(e.getRawY() - ty);
                    if (dx < dp(8) && dy < dp(8) && System.currentTimeMillis() - down < 450) {
                        togglePanel();
                    } else {
                        getSharedPreferences("toolbox", MODE_PRIVATE).edit()
                                .putInt("main_bubble_x", bubbleLp.x)
                                .putInt("main_bubble_y", bubbleLp.y)
                                .apply();
                    }
                    return true;
            }
            return false;
        }
    }

    private class ShortcutTouch implements View.OnTouchListener {
        private final Shortcut shortcut;
        private final Button view;
        private final WindowManager.LayoutParams lp;
        private int sx, sy;
        private float tx, ty;
        private long down;

        ShortcutTouch(Shortcut shortcut, Button view, WindowManager.LayoutParams lp) {
            this.shortcut = shortcut;
            this.view = view;
            this.lp = lp;
        }

        @Override
        public boolean onTouch(View v, MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    sx = lp.x;
                    sy = lp.y;
                    tx = e.getRawX();
                    ty = e.getRawY();
                    down = System.currentTimeMillis();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    lp.x = sx + (int) (e.getRawX() - tx);
                    lp.y = sy + (int) (e.getRawY() - ty);
                    clamp(lp, 56);
                    try { wm.updateViewLayout(view, lp); } catch (Exception ignored) {}
                    return true;
                case MotionEvent.ACTION_UP:
                    float dx = Math.abs(e.getRawX() - tx);
                    float dy = Math.abs(e.getRawY() - ty);
                    long held = System.currentTimeMillis() - down;
                    if (dx < dp(8) && dy < dp(8)) {
                        if (held >= 650) editShortcut(shortcut);
                        else run(shortcut.command);
                    } else {
                        getSharedPreferences("toolbox", MODE_PRIVATE).edit()
                                .putInt("shortcut_x_" + shortcut.id, lp.x)
                                .putInt("shortcut_y_" + shortcut.id, lp.y)
                                .apply();
                    }
                    return true;
            }
            return false;
        }
    }
}
