package com.aziz.toolbox2645;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private static final int REQ_OVERLAY = 42;
    private TextView status;

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String s, int size, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setPadding(dp(4), dp(7), dp(4), dp(7));
        return t;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(16);
        return b;
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);

        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 77);
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(22), dp(22), dp(22));
        root.setBackgroundColor(Color.rgb(232, 255, 220));
        root.setGravity(Gravity.CENTER_HORIZONTAL);

        ImageView icon = new ImageView(this);
        icon.setImageResource(com.aziz.toolbox2645.R.drawable.toolbox_icon);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(112), dp(112));
        ip.bottomMargin = dp(8);
        root.addView(icon, ip);

        TextView title = text("Toolbox 26.45", 28, Color.rgb(20, 45, 20));
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, 1);
        root.addView(title);

        TextView sub = text("Temiz Android sürümü • Minecraft Bedrock", 14, Color.DKGRAY);
        sub.setGravity(Gravity.CENTER);
        root.addView(sub);

        status = text("", 15, Color.rgb(20, 60, 25));
        status.setGravity(Gravity.CENTER);
        root.addView(status);

        Button overlay = button("1) Yüzen Toolbox iznini ver");
        overlay.setOnClickListener(v -> requestOverlayPermission());
        root.addView(overlay, new LinearLayout.LayoutParams(-1, -2));

        Button start = button("2) Toolbox HUD'u başlat");
        start.setOnClickListener(v -> startToolbox());
        root.addView(start, new LinearLayout.LayoutParams(-1, -2));

        Button copy = button("3) Minecraft bağlantı komutunu kopyala");
        copy.setOnClickListener(v -> {
            String cmd = "/connect 127.0.0.1:19132";
            ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("Minecraft Toolbox", cmd));
            Toast.makeText(this, "Komut kopyalandı: " + cmd, Toast.LENGTH_LONG).show();
        });
        root.addView(copy, new LinearLayout.LayoutParams(-1, -2));

        Button mc = button("4) Minecraft'ı aç");
        mc.setOnClickListener(v -> openMinecraft());
        root.addView(mc, new LinearLayout.LayoutParams(-1, -2));

        TextView info = text(
                "\nİlk bağlantı:\n" +
                "• Önce Toolbox HUD'u başlat.\n" +
                "• Dünyada hileleri aç.\n" +
                "• Sohbete /connect 127.0.0.1:19132 yaz.\n" +
                "• BAĞLI yazınca yüzen komut dairelerine dokun.\n\n" +
                "Renkli daireler sürüklenebilir; uzun basınca düzenlenir. " +
                "Free Camera Bedrock'ın kendi /camera sistemini kullanır.",
                14, Color.rgb(45, 55, 45));
        root.addView(info);

        setContentView(root);
        updateStatus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateStatus();
    }

    private void updateStatus() {
        boolean overlay = Settings.canDrawOverlays(this);
        boolean connected = CommandWebSocketServer.get().isConnected();
        if (status != null) {
            status.setText("Overlay: " + (overlay ? "HAZIR" : "İZİN GEREKİYOR") +
                    "\nMinecraft bağlantısı: " + (connected ? "BAĞLI" : "BEKLİYOR"));
        }
    }

    private void requestOverlayPermission() {
        if (Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Yüzen pencere izni zaten açık.", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()));
        startActivityForResult(i, REQ_OVERLAY);
    }

    private void startToolbox() {
        if (!Settings.canDrawOverlays(this)) {
            requestOverlayPermission();
            return;
        }
        Intent s = new Intent(this, OverlayService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(s);
        else startService(s);
        Toast.makeText(this, "Toolbox HUD başlatıldı.", Toast.LENGTH_SHORT).show();
    }

    private void openMinecraft() {
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage("com.mojang.minecraftpe");
            if (i != null) startActivity(i);
            else Toast.makeText(this, "Minecraft bulunamadı.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Minecraft açılamadı: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
