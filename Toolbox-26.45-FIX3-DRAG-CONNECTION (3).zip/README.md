# Toolbox 26.45 Clean — Android

Bu proje eski Toolbox APK'sını yamalamaz. Tamamen temiz bir Android companion uygulamasıdır.

## Özellikler
- Minecraft'ın üstünde sürüklenebilir yeşil sandık düğmesi
- Küçük açılır Toolbox paneli
- Rengi değiştirilebilir komut daireleri
- Komut dairesine dokununca komutu doğrudan Minecraft'a gönderme
- Give Item
- Effects
- Enchant
- Heal / Feed / Clear
- Free Camera / Camera Reset
- Minecraft APK'sına inject/hook yapılmaz

## Minecraft bağlantısı
Uygulama telefonda yerel bir WebSocket sunucusu açar.

1. Toolbox uygulamasını aç.
2. "Diğer uygulamaların üzerinde göster" iznini ver.
3. Toolbox HUD'u başlat.
4. Minecraft 26.45'i aç.
5. Hilelerin açık olduğu dünyaya gir.
6. Sohbete:
   /wsserver ws://127.0.0.1:19132
   yaz.
7. Toolbox üzerinde "Minecraft BAĞLI" görünür.
8. Bundan sonra Toolbox düğmelerine dokunduğunda komut direkt oyunda çalışır.

## Free Camera
"Free Camera" düğmesi:
- /camera @s set minecraft:free
- /controlscheme @s set camera_relative

"Camera Reset":
- /camera @s clear
- /controlscheme @s clear

Bu, Bedrock'ın kendi kamera komut sistemidir; eski Toolbox'taki native memory freecam ile aynı teknik değildir.

## APK üretme — en kolay yöntem
Projeyi GitHub'a yükle. `.github/workflows/build-apk.yml` otomatik olarak debug APK üretir.
GitHub > Actions > Build Toolbox APK > son çalışma > Artifacts > Toolbox-26.45-debug dosyasını indir.

Alternatif: Android Studio ile projeyi açıp Build > Build APK(s).
